import React from 'react'
import { Route ,Link} from 'react-router-dom'
import {  Segment } from 'semantic-ui-react'
import Carousel from "semantic-ui-carousel-react";
import { Image, Button } from "semantic-ui-react";
import image1 from "./connect2.jpg"
import image2 from "./connect3.jpg"
// import "react-responsive-carousel/lib/styles/carousel.min.css";
// import { Carousel } from 'react-responsive-carousel';
export default function home() {
    let elements = [
        {
            render: () => {
              return (<div style={{height:200,width:250}}><br></br><br></br>
                <h2 style={{color:'green',fontFamily:'OCR A Std' ,textAlign:'center'}}>CONNECTING <br></br>PEOPLE</h2>
                </div>);
            }
          },
        {
          render: () => {
            return (
              <Image src={image1} style={{height:200,width:250}}/>
            );
          }
        },
        {
          render: () => {
            return <Image src={image2} style={{height:200,width:250}} />;
          }
        }
     
      ];
    return (
        <div  >
         
<Carousel
        elements={elements}
        duration={2000}
        animation="slide left"
        showNextPrev={false}
        showIndicators={true}
        
      />
      
 <Link to='/facebook'>
  <Segment circular floated='right' inverted color='blue'style={{ width: 5, height:5 }}><div style={{fontSize:33}}>f</div></Segment></Link>
  


        </div>
    )
}
