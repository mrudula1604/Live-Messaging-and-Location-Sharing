import React from 'react'

export default function cakeComponents() {
    return (
        <div>
            <h2>
                no of cakes
            </h2>
            <button>Buy cake</button>
        </div>
    )
}
