import React, { Component } from 'react'
import { Map, TileLayer, Marker, Popup } from 'react-leaflet'
import L from 'leaflet'
import {connect} from 'react-redux'
import { Button } from 'semantic-ui-react'
export const suitcasePoint = new L.Icon({
  iconUrl: require('../vespa.svg'),
  // iconRetinaUrl: 'car',
  iconAnchor: [20, 40],
  popupAnchor: [0, -35],
  iconSize: [30, 30],
  // shadowUrl: '../assets/marker-shadow.png',
  // shadowSize: [29, 40],
  // shadowAnchor: [7, 40],
})
const mapStateToProps =(state)=>{
  
  
  return ({phno:state.loginReducer.phno,Uname:state.loginReducer.UName,lati:state.geoReducer.lat,lani:state.geoReducer.lan,data:state.geoReducer.wholeLatAndLan})
} 
 class maps extends Component{
  state = {
    lat: this.props.lati,
    lng: this.props.lani,
    zoom:17,
  }
  markers=[]
  render() {
    const position = [this.props.lati,this.props.lani]
    return (
      <Map center={position} zoom={this.state.zoom}>
        <TileLayer
          attribution='&amp;copy <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {/* <Marker position={position} icon={suitcasePoint}>
          <Popup><br></br>
        {this.props.UName}<br></br>
          </Popup>
          
        </Marker> */}
        
                    {this.markers=this.props.data.map((data)=>{
                              console.log(data)
                              if(data.phno==this.props.phno )
                       return(<Marker key={data.phno} position={[data.lat,data.long]}>
                                      <Popup>
                                     {data.Uname}<br /> {data.phno }
                                       </Popup>
                              </Marker>)
                              else if(data.oPhno==this.props.oPhno){
                                return(<Marker color="red" key={data.phno} position={[data.lat,data.long]}>
                                  <Popup>
                                 {data.Uname}<br /> {data.phno }
                                   </Popup>
                          </Marker>)
                              }
                              else{
                                return""
                              }
                      })}
      {this.markers}
      </Map>
    )
  }
}

export default maps= connect(mapStateToProps)(maps)