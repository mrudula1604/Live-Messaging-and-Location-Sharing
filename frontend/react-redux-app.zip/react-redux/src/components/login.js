import React, { Component } from 'react'
import { Input, Segment } from 'semantic-ui-react'
import { Button, Grid } from 'semantic-ui-react'
import socketIOClient from "socket.io-client";
import { Route, Redirect,Link} from 'react-router-dom'
import { connect } from "react-redux";
import { logina } from '../Redux/login/loginAction';


export class login extends Component {
    constructor(props){
        super()
        this.state={phoneNo:"",userName:'',formerror:{pheror:"Please enter number",nameeror:"Please enter name"}}
       
    }
    getphno=(e)=>{
        
        this.setState({phoneNo:e.target.value})
if(e.target.value[0]!=='0'){
    if(e.target.value.length===10){
        this.setState((prevestate)=>{return({formerror:{pheror:"",nameeror:prevestate.formerror.nameeror}})})
    }
    else{
        this.setState((prevestate)=>{return({formerror:{pheror:"enter 10 digits",nameeror:prevestate.formerror.nameeror}})})

    }
}
else{
    this.setState((prevestate)=>{return({formerror:{pheror:"Please enter Valid number",nameeror:prevestate.formerror.nameeror}})})
}
      
    }
    getUName=(e)=>{

        this.setState({userName:e.target.value})
        if(e.target.value.length!=0){
            this.setState((prevestate)=>{return({formerror:{pheror:prevestate.formerror.pheror,nameeror:""}})})
        }
        else{
            this.setState((prevestate)=>{return({formerror:{pheror:prevestate.formerror.pheror,nameeror:"Please enter name"}})})
        }
    }
    submitPhoneNo= ()=>{
        const socket = socketIOClient('http://localhost:4000/');
        socket.emit("setUsername",{phno:this.state.phoneNo,username:this.state.userName})
        this.props.logina(this.state)
       
    }
    render() {
        return (
            <div>
   <Segment color={this.state.formerror.pheror?'red':'blue'}>     

 <Grid>
<Grid.Column width={8}>
      <Input icon='user' iconPosition='left' type="number" value={this.state.phoneNo} placeholder='Enter User phone no' onChange={this.getphno} />
      </Grid.Column>
      
      {this.state.formerror.pheror?<Grid.Column width={9}><Segment color='red' inverted>{this.state.formerror.pheror}</Segment></Grid.Column>:''}
       
      </Grid></Segment><Segment color={this.state.formerror.nameeror?'red':'blue'}><Grid>
      
      <Grid.Column width={8}>  <Input icon='user' iconPosition='left' type="text" value={this.state.userName} placeholder='Enter User name' onChange={this.getUName} />
    
      </Grid.Column> {this.state.formerror.nameeror?<Grid.Column width={9}><Segment color='red' inverted>{this.state.formerror.nameeror}</Segment></Grid.Column>:''}</Grid> </Segment>
     
      <Grid>
      
      <Link to={"/friends"} ><Button disabled={this.state.formerror.pheror?true:false}
            content='login'
            primary
            onClick={this.submitPhoneNo}
          /></Link>
            </Grid>
     
       
            </div>
        )
    }
 
}
function mapDispatchToProps(dispatch){
    return {
    logina: data=>{dispatch(logina(data))}
    }
  }
export default login= connect(null,mapDispatchToProps)(login)   