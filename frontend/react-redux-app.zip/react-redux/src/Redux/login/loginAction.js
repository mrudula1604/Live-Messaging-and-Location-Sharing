import {LOGED_IN, LOG_OUT} from './loginTypes'
export const logina = (data)=>{
    return{
        type:LOGED_IN,
        phNo:data.phoneNo,
        UName:data.userName
    }
}
export const logout = ()=>{
    return{
        type:LOG_OUT,
        phNo:'',
        UName:''
    }
}