export const LOGED_IN='LOGED_IN'
export const LOG_OUT='LOG_OUT'