export var  IntialState={
    isLogedIn:false,
    phno:'',
    UName:'',
    active:'home',
    lat:'',
    long:'',
}